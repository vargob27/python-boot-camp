from django.shortcuts import render, redirect
from django.utils.crypto import get_random_string

def index(request):
    return render(request, 'index.html')

def random(request):
    context = {
        "random":get_random_string(length=14)
        }
    
    return render(request, 'random_word.html', context)

def reset(request):
    return render(request, 'reset.html')