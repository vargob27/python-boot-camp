from django.apps import AppConfig


class CourseAppConfig(AppConfig):
    name = 'course_app'
